from django.apps import AppConfig


class StudentsTgBotConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'students_tg_bot'
