from django.apps import AppConfig


class ProfessorsTgBotConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'professors_tg_bot'
