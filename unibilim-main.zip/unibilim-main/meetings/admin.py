from django.contrib import admin
from .models import Meetings
# Register your models here.
admin.site.register(Meetings)