from django.contrib import admin
from .models import Payments
# Register your models here.
admin.site.register(Payments)